# app.py – Simulador Macroeconómico (EMAE, IPC, TCN, ITCRM)
# -----------------------------------------------------------
import pandas as pd
import streamlit as st
import plotly.express as px
import statsmodels.api as sm
from pathlib import Path

st.set_page_config(page_title="Simulador Macroeconómico Unidad 1", layout="wide")

INTRO = r"""# Simulador Macroeconómico
Este tablero permite **explorar** y **simular** cómo los cambios en IPC, TCN e ITCRM impactan sobre el EMAE.

### Paso rápido en Anaconda
```bash
conda env create -f environment.yml
conda activate macroenv
streamlit run app.py
```
"""
st.markdown(INTRO)

DATA_PATH = Path("macrou1_subset.csv")
if not DATA_PATH.exists():
    st.error("Falta macrou1_subset.csv en la carpeta raíz.")
    st.stop()

df = pd.read_csv(DATA_PATH, parse_dates=["fecha"]).sort_values("fecha")

modo = st.sidebar.radio("Modo", ["Exploración", "Simulador"])

if modo == "Exploración":
    var = st.selectbox("Variable", ["EMAE", "IPC", "TCN Promedio mensual", "ITCRM"])
    fig = px.line(df, x="fecha", y=var, title=var)
    st.plotly_chart(fig, use_container_width=True)
else:
    fechas = df["fecha"].dt.strftime("%Y-%m").tolist()
    fstr = st.selectbox("Mes base", fechas, index=len(fechas)-1)
    fbase = pd.to_datetime(fstr + "-01")
    base = df.loc[df["fecha"] == fbase].iloc[0]

    col1, col2, col3 = st.columns(3)
    with col1:
        d_ipc = st.slider("Shock IPC (%)", -30.0, 30.0, 0.0, 1.0)
    with col2:
        d_tcn = st.slider("Shock TCN (%)", -30.0, 30.0, 0.0, 1.0)
    with col3:
        d_itcrm = st.slider("Shock ITCRM (%)", -30.0, 30.0, 0.0, 1.0)

    X = sm.add_constant(df[["IPC", "TCN Promedio mensual", "ITCRM"]])
    y = df["EMAE"]
    model = sm.OLS(y, X).fit()

    X_new = [1,
             base["IPC"] * (1 + d_ipc / 100),
             base["TCN Promedio mensual"] * (1 + d_tcn / 100),
             base["ITCRM"] * (1 + d_itcrm / 100)]
    emae_sim = float(model.predict([X_new]))
    diff_pct = (emae_sim - base["EMAE"]) / base["EMAE"] * 100

    st.metric("EMAE simulado", f"{emae_sim:.2f}", f"{diff_pct:+.2f}%")
    st.write("Histórico EMAE:", base["EMAE"])
