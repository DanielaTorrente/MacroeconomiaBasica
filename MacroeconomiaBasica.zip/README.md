# Simulador Macroeconómico – Unidad 1

Tablero Streamlit para explorar EMAE, IPC, TCN e ITCRM y simular impactos.

## Uso local

```bash
conda env create -f environment.yml
conda activate macroenv
streamlit run app.py
```

## Despliegue en Streamlit Cloud

1. Sube este repo a GitHub
2. Nuevo app → selecciona el repo → `app.py` como archivo principal
